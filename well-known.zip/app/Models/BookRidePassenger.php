<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookRidePassenger extends Model
{
    use HasFactory;

    protected $fillable = ['passenger_id','ride_id']

}

('rides_id')->unsigned;
            $table->integer('passenger_id')->unsigned;
            

            $table->string('pickup_location');
            $table->string('end_location');
            $table->decimal('start_latitude');
            $table->decimal('start_longitude');
