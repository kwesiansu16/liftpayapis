<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    //

   // $request->validate([....]);

   /*public function form1(Request $request){
    $request->validate([....]);
    save the form and return redirect to your payment form like this
    ..
    return redirect('/pay');
    }
} */


/*public function spatie(){
    
}*/



}
